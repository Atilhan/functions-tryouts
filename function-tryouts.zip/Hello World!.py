
def world(loopy):
    for a in range(loopy):
        print ("Hello World")

world(5)

