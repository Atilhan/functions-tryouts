def showWelcome(welcomeTo:str="town"):
    print("welcome to function " + welcomeTo )

where = "town" 
showWelcome(where)