def math_1(plus):
  return 10 + plus

def math_2(minus):
  return 58 - minus

def math_3(multiply):
  return 6 * multiply

def math_4(divide):
  return 144 / (divide)

def math_5(plus_1):
  return 12 + (plus_1)

def math_6(minus_1):
  return 34 - (minus_1)

#----------------------------------------#

print ("10 + 12 = ", math_1(12))
print("------------------------")
print ("58 - 34 = ", math_2(34))
print("------------------------")
print("6 * 7 = ", math_3(7))
print("------------------------")
print("144 : 12 = ", int(math_4(12)))
print("------------------------")
print("12 + 1 = ", math_5(1))
print("------------------------")
print("34 - 1 = ", math_6(1))